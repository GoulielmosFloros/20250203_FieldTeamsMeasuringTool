import * as OBC from "@thatopen/components";
import * as OBF from "@thatopen/components-front";
import * as THREE from "three";

export class OpeningMeasurement extends OBC.Component {
  static uuid = "789dff24-72e5-4641-8de1-a0aa1ebf1bf7" as const;
  enabled = true;

  private _world: OBC.World | null = null;
  set world(value: OBC.World | null) {
    this._world = value;
    if (value) {
      value.scene.three.add(this._edgePreview);
    } else {
      this._edgePreview.removeFromParent();
    }
  }

  get world() {
    return this._world;
  }

  private _edge: THREE.Line3 | null = null;

  set edge(value: THREE.Line3 | null) {
    this._edge = value;
    this._edgePreview.visible = !!value;
    if (!value) return;
    const previewGeometry = this._edgePreview.geometry;
    previewGeometry.setFromPoints([value.start, value.end]);
    previewGeometry.attributes.position.needsUpdate = true;
    previewGeometry.computeBoundingBox();
    previewGeometry.computeBoundingSphere();
  }

  get edge() {
    return this._edge;
  }

  private _edgePreview = new THREE.Line(
    new THREE.BufferGeometry(),
    new THREE.LineBasicMaterial({
      color: "red",
      depthTest: false,
    }),
  );

  constructor(components: OBC.Components) {
    super(components);
    components.add(OpeningMeasurement.uuid, this);
  }

  edges: THREE.Vector3[][] = [];

  measure() {
    if (!this.edge) return;
    const edge = this.edge;
    const edgeDirection = new THREE.Vector3();
    edge.delta(edgeDirection);
    edgeDirection.normalize();

    const vertices = this.edges.flat();

    const farthestFromStart = vertices.reduce((prev, curr) => {
      const currLine = new THREE.Line3(edge.start, curr);
      const currLineDir = new THREE.Vector3();
      currLine.delta(currLineDir);
      if (currLineDir.dot(edgeDirection) >= 0) return prev;

      const prevLine = new THREE.Line3(edge.start, prev);
      if (currLine.distance() > prevLine.distance()) return curr;
      return prev;
    }, edge.start);

    const farthestFromEnd = vertices.reduce((prev, curr) => {
      const currLine = new THREE.Line3(edge.end, curr);
      const currLineDir = new THREE.Vector3();
      currLine.delta(currLineDir);
      if (currLineDir.dot(edgeDirection) <= 0) return prev;

      const prevLine = new THREE.Line3(edge.end, prev);
      if (currLine.distance() > prevLine.distance()) return curr;
      return prev;
    }, edge.end);

    const lengthMeasurement = this.components.get(OBF.LengthMeasurement);

    if (!edge.start.equals(farthestFromStart)) {
      const projection = new THREE.Vector3();
      edge.closestPointToPoint(farthestFromStart, false, projection);
      const line = new THREE.Line3(edge.start, projection);
      if (line.distance() > 0) {
        lengthMeasurement.createOnPoints(edge.start, projection);
      }
    }

    if (!edge.end.equals(farthestFromEnd)) {
      const projection = new THREE.Vector3();
      edge.closestPointToPoint(farthestFromEnd, false, projection);
      const line = new THREE.Line3(edge.end, projection);
      if (line.distance() > 0) {
        lengthMeasurement.createOnPoints(edge.end, projection);
      }
    }
  }

  reset() {
    this.edges = [];
    this.edge = null;
  }
}
